
	<div class="main-panel">

        <div class="content">
            <div class="container-fluid">
							<h2>Admin Dashboard</h2>
</div>




    </div>
