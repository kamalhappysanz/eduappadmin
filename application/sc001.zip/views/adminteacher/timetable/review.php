<div class="content">
     <div class="container-fluid">
         <div class="row">
             <div class="col-md-12">
                 <div class="card">
                     <div class="content">

                         <div class="fresh-datatables">


                   <table id="bootstrap-table" class="table">
                       <thead>

                           <th data-field="id" class="text-center">ID</th>
                         <th data-field="name" class="text-center" data-sortable="true">Class</th>
                         <th data-field="Section" class="text-center" data-sortable="true">Action</th>


                       </thead>
                       <tbody>
                         <?php
                         $i=1;
                         foreach ($result as $rows) {
                         ?>
                           <tr>
                             <td><?php echo $i; ?></td>
                             <td><?php echo $rows->class_name; ?></td>
                             <td>
                               <a href="<?php echo base_url();  ?>classadd/updateclass/<?php echo $rows->class_id; ?>" class="btn btn-simple btn-warning btn-icon edit"><i class="fa fa-edit"></i></a>
                               <!-- <a href="<?php echo base_url();  ?>classadd/delete_class/<?php echo $rows->class_id; ?>" class="btn btn-simple btn-danger btn-icon "><i class="fa fa-times"></i></a> -->


                             </td>
                           </tr>
                           <?php $i++;  }  ?>
                       </tbody>
                   </table>

                 </div>
                     </div><!-- end content-->
                 </div><!--  end card  -->
             </div> <!-- end col-md-12 -->
         </div> <!-- end row -->

     </div>
 </div>
