<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-01 06:58:07 --> Config Class Initialized
INFO - 2017-03-01 06:58:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 06:58:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 06:58:07 --> Utf8 Class Initialized
INFO - 2017-03-01 06:58:07 --> URI Class Initialized
DEBUG - 2017-03-01 06:58:07 --> No URI present. Default controller set.
INFO - 2017-03-01 06:58:07 --> Router Class Initialized
INFO - 2017-03-01 06:58:07 --> Output Class Initialized
INFO - 2017-03-01 06:58:07 --> Security Class Initialized
DEBUG - 2017-03-01 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 06:58:07 --> Input Class Initialized
INFO - 2017-03-01 06:58:07 --> Language Class Initialized
ERROR - 2017-03-01 06:58:07 --> 404 Page Not Found: Home/index
INFO - 2017-03-01 06:58:08 --> Config Class Initialized
INFO - 2017-03-01 06:58:08 --> Hooks Class Initialized
DEBUG - 2017-03-01 06:58:08 --> UTF-8 Support Enabled
INFO - 2017-03-01 06:58:08 --> Utf8 Class Initialized
INFO - 2017-03-01 06:58:08 --> URI Class Initialized
DEBUG - 2017-03-01 06:58:08 --> No URI present. Default controller set.
INFO - 2017-03-01 06:58:08 --> Router Class Initialized
INFO - 2017-03-01 06:58:08 --> Output Class Initialized
INFO - 2017-03-01 06:58:09 --> Security Class Initialized
DEBUG - 2017-03-01 06:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 06:58:09 --> Input Class Initialized
INFO - 2017-03-01 06:58:09 --> Language Class Initialized
ERROR - 2017-03-01 06:58:09 --> 404 Page Not Found: Home/index
INFO - 2017-03-01 07:00:14 --> Config Class Initialized
INFO - 2017-03-01 07:00:14 --> Hooks Class Initialized
DEBUG - 2017-03-01 07:00:14 --> UTF-8 Support Enabled
INFO - 2017-03-01 07:00:14 --> Utf8 Class Initialized
INFO - 2017-03-01 07:00:14 --> URI Class Initialized
DEBUG - 2017-03-01 07:00:14 --> No URI present. Default controller set.
INFO - 2017-03-01 07:00:14 --> Router Class Initialized
INFO - 2017-03-01 07:00:14 --> Output Class Initialized
INFO - 2017-03-01 07:00:14 --> Security Class Initialized
DEBUG - 2017-03-01 07:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 07:00:14 --> Input Class Initialized
INFO - 2017-03-01 07:00:14 --> Language Class Initialized
ERROR - 2017-03-01 07:00:14 --> 404 Page Not Found: Home/index
INFO - 2017-03-01 07:02:54 --> Config Class Initialized
INFO - 2017-03-01 07:02:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 07:02:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 07:02:54 --> Utf8 Class Initialized
INFO - 2017-03-01 07:02:54 --> URI Class Initialized
DEBUG - 2017-03-01 07:02:54 --> No URI present. Default controller set.
INFO - 2017-03-01 07:02:54 --> Router Class Initialized
INFO - 2017-03-01 07:02:54 --> Output Class Initialized
INFO - 2017-03-01 07:02:54 --> Security Class Initialized
DEBUG - 2017-03-01 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 07:02:54 --> Input Class Initialized
INFO - 2017-03-01 07:02:54 --> Language Class Initialized
ERROR - 2017-03-01 07:02:54 --> 404 Page Not Found: Home/index
